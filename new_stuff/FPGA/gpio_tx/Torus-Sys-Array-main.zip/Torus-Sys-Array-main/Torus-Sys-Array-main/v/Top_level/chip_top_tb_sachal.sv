// -----------------------------------------------------------------------
// chip_top_tb.sv
//
// Combined SPI + bsg_link testbench for chip_top.sv.
//
// Setup:
//   - Drive chip's RX-side pads from a peer bsg_link_ddr_upstream
//     instance acting as the FPGA TX endpoint.
//   - Capture chip's TX-side pads with a peer bsg_link_ddr_downstream
//     instance acting as the FPGA RX endpoint.
//   - SPI master driven from a simple task.
//
// Test sequence:
//   1) Reset all link / token / core resets in stages.
//   2) Wait for the chip's status TX to become valid.
//   3) Send 10 bsg_link RX words ("config write") to set link_cfg_active.
//   4) Verify chip's TX status echoes link_cfg_active=1 and rx_word_count.
//   5) SPI write that asserts spi_reg_enable.
//   6) Verify chip's TX status echoes spi_reg_enable=1.
// -----------------------------------------------------------------------
`timescale 1ps/1ps

module chip_top_tb;

    // -------- dump waveform -----------
    initial begin 
        $fsdbDumpfile("waveform.fsdb");
        $fsdbDumpvars("+all");
        $fsdbDumpvars(0, chip_top_tb);  // 0 = all levels, chip_top_tb = top scope
        $fsdbDumpMDA();
    end

    localparam int FLIT_WIDTH    = 32;
    localparam int DATA_WIDTH    = 32;
    localparam int CHANNEL_WIDTH = 17;

    // // ----- Clocks + global control -----
    // logic core_clk;
    // logic dn_io_clk;          // FPGA's TX I/O master clock; bsg_link_oddr_phy ÷2 → 50 MHz forwarded to PAD[8]
    // logic hard_reset;

    // Core clock — drives DUT core domain (same period as tb clock)
    logic core_clk;
    bsg_nonsynth_clock_gen #(12000) clk_gen_core (core_clk);
    
    // IO master clock — dedicated high-speed clock for bsg_link upstream IO domain
    // Must be provided separately; use 2x core speed (6000ps = half of 12000ps period)
    logic io_master_clk;
    bsg_nonsynth_clock_gen #(6000) clk_gen_io_master (io_master_clk);

    // ============================================================
    // Testbench Reset (for trace replays only)
    // ============================================================
    logic hard_reset;
    bsg_nonsynth_reset_gen #(
        .num_clocks_p    (1),
        .reset_cycles_lo_p(1),
        .reset_cycles_hi_p(2)
    ) reset_gen_tb (
        .clk_i        ( core_clk   ),
        .async_reset_o( hard_reset )
    );

    wire hard_reset_sync;
    async_rst_sync_deassert u_hard_reset_sync(
        .clk        (core_clk),
        .rst        (hard_reset),
        .async_rst_sync_deassert(hard_reset_sync)
    );




    // // ----- Reset stages (mirrors bsg_link reference tb staging) -----
    // logic fpga_core_reset;
    // logic fpga_tx_io_link_reset;
    // logic fpga_tx_async_token_reset;
    // logic fpga_rx_io_link_reset;
    // logic fpga_rx_io_link_reset_sync;

    // ----- Pad bus -----
    wire vdd_io = 1'b1;
    wire vss_io = 1'b0;
    tri  [47:0] pad;
    logic [47:0] pad_drv;
    logic [47:0] pad_oe;

    function automatic logic kz(input logic v);
        kz = (v === 1'b1) ? 1'b1 : 1'b0;
    endfunction

    genvar pad_idx;
    generate
        for (pad_idx = 0; pad_idx < 48; pad_idx++) begin : gen_pad_drive
            assign pad[pad_idx] = pad_oe[pad_idx] ? pad_drv[pad_idx] : 1'bz;
        end
    endgenerate

    chip_top uut (
        .PAD   (pad),
        .VDDPST(vdd_io),
        .VSSPST(vss_io),
        .VDD   (vdd_io),
        .VSS   (vss_io)
    );

    // ----- bsg_link wires shared with chip's PAD bus -----
    logic                       fpga_to_asic_clk;
    logic                       fpga_to_asic_valid;
    logic [CHANNEL_WIDTH-1:0]   fpga_to_asic_data;
    logic                       fpga_to_asic_token;   // FPGA RX -> chip TX token_clk
    logic                       asic_to_fpga_token;   // chip RX -> FPGA TX token
    logic                       asic_to_fpga_clk;
    logic                       asic_to_fpga_valid;
    logic [CHANNEL_WIDTH-1:0]   asic_to_fpga_data;

    // Drive chip's RX-side pads
    assign pad_drv[44] = kz(core_clk);
    assign pad_drv[45] = kz(hard_reset);
    assign pad_drv[8]  = kz(fpga_to_asic_clk);
    assign pad_drv[9]  = kz(fpga_to_asic_valid);

    // dn_data interleave per chip_top.sv's dn_data_pad():
    //   bits[0..7]  -> PAD[0..7]
    //   bit  8 -> PAD[37], bit  9 -> PAD[36],
    //   bit 10 -> PAD[39], bit 11 -> PAD[38],
    //   bit 12 -> PAD[41], bit 13 -> PAD[40],
    //   bit 14 -> PAD[43], bit 15 -> PAD[42]
    assign pad_drv[0]  = kz(fpga_to_asic_data[0]);
    assign pad_drv[1]  = kz(fpga_to_asic_data[1]);
    assign pad_drv[2]  = kz(fpga_to_asic_data[2]);
    assign pad_drv[3]  = kz(fpga_to_asic_data[3]);
    assign pad_drv[4]  = kz(fpga_to_asic_data[4]);
    assign pad_drv[5]  = kz(fpga_to_asic_data[5]);
    assign pad_drv[6]  = kz(fpga_to_asic_data[6]);
    assign pad_drv[7]  = kz(fpga_to_asic_data[7]);
    assign pad_drv[37] = kz(fpga_to_asic_data[8]);
    assign pad_drv[36] = kz(fpga_to_asic_data[9]);
    assign pad_drv[39] = kz(fpga_to_asic_data[10]);
    assign pad_drv[38] = kz(fpga_to_asic_data[11]);
    assign pad_drv[41] = kz(fpga_to_asic_data[12]);
    assign pad_drv[40] = kz(fpga_to_asic_data[13]);
    assign pad_drv[43] = kz(fpga_to_asic_data[14]);
    assign pad_drv[42] = kz(fpga_to_asic_data[15]);
    assign pad_drv[27] = kz(fpga_to_asic_data[16]);

    // chip's token_clk input PAD[12] receives the FPGA RX-side token
    // (the returned-credit signal generated by fpga_rx_link.core_token_r_o).
    assign pad_drv[12] = kz(fpga_to_asic_token);

    /*
    // SPI controls - ???
    logic SCLK, MOSI, SS_n;
    wire  MISO;
    assign pad_drv[13] = kz(SCLK);
    assign pad_drv[24] = kz(MOSI);
    assign pad_drv[26] = kz(SS_n);
    assign MISO         = pad[25];
    */

    // DFT scan inputs tied off in functional sim
    assign pad_drv[11] = 1'b0;
    assign pad_drv[46] = 1'b0;
    // assign scan_out = pad_drv[47]

    // Sample chip's TX-side pads
    assign asic_to_fpga_clk   = pad[15];
    assign asic_to_fpga_valid = pad[14];
    assign asic_to_fpga_token = pad[10];

    // up_data interleave per chip_top.sv's up_data_pad()
    assign asic_to_fpga_data[0]  = pad[22];
    assign asic_to_fpga_data[1]  = pad[23];
    assign asic_to_fpga_data[2]  = pad[20];
    assign asic_to_fpga_data[3]  = pad[21];
    assign asic_to_fpga_data[4]  = pad[18];
    assign asic_to_fpga_data[5]  = pad[19];
    assign asic_to_fpga_data[6]  = pad[16];
    assign asic_to_fpga_data[7]  = pad[17];
    assign asic_to_fpga_data[8]  = pad[28];
    assign asic_to_fpga_data[9]  = pad[29];
    assign asic_to_fpga_data[10] = pad[30];
    assign asic_to_fpga_data[11] = pad[31];
    assign asic_to_fpga_data[12] = pad[32];
    assign asic_to_fpga_data[13] = pad[33];
    assign asic_to_fpga_data[14] = pad[34];
    assign asic_to_fpga_data[15] = pad[35];
    assign asic_to_fpga_data[16] = pad[13];

    // ----- FPGA-side bsg_link instances (peers to chip's wrapper) -----
    logic [DATA_WIDTH-1:0] fpga_tx_data;
    logic                  fpga_tx_valid;
    logic                  link_tx_ready;
    logic [DATA_WIDTH-1:0] link_rx_data;
    logic                  link_rx_valid;
    logic                  fpga_rx_yumi;
    logic                  link_rx_parity_error;

    // logic                  tx_data_i; // This is the data that comes out of trace replay
    // logic                  tx_parity_low;
    // logic                  tx_parity_high;
    // logic                  rx_ok_low;
    // logic                  rx_ok_high;
    // logic                  rx_data_o; // This is the data that goes into trace replay
    // logic                  rx_parity_error_o;

    /*
    // TX PATH: Parity Generation & Upstream
    parity_generator #(.WIDTH_p(16)) pg_low (
        .bits_i(tx_data_i[15:0]),
        .parity_o(tx_parity_low)
    );

    parity_generator #(.WIDTH_p(16)) pg_high (
        .bits_i(tx_data_i[31:16]),
        .parity_o(tx_parity_high)
    );

    assign fpga_tx_data = {
        tx_parity_high,
        tx_data_i[31:16],
        tx_parity_low,
        tx_data_i[15:0]
    };

    bsg_link_ddr_upstream #(
        .width_p        (FLIT_WIDTH),
        .channel_width_p(CHANNEL_WIDTH),
        .num_channels_p (1),
        .lg_fifo_depth_p(6)
    ) fpga_tx_link (
        .core_clk_i         (core_clk),
        .core_link_reset_i  (fpga_core_reset),
        .core_data_i        (fpga_tx_data),
        .core_valid_i       (fpga_tx_valid),
        .core_ready_o       (fpga_tx_ready),
        .io_clk_i           (dn_io_clk),
        .io_link_reset_i    (fpga_tx_io_link_reset),
        .async_token_reset_i(fpga_tx_async_token_reset),
        .io_clk_r_o         (fpga_to_asic_clk),
        .io_data_r_o        (fpga_to_asic_data),
        .io_valid_r_o       (fpga_to_asic_valid),
        .token_clk_i        (asic_to_fpga_token)
    );

    bsg_sync_sync #(.width_p(1)) fpga_rx_reset_sync (
        .oclk_i      (asic_to_fpga_clk),
        .iclk_data_i (fpga_rx_io_link_reset),
        .oclk_data_o (fpga_rx_io_link_reset_sync)
    );

    bsg_link_ddr_downstream #(
        .width_p        (FLIT_WIDTH),
        .channel_width_p(CHANNEL_WIDTH),
        .num_channels_p (1),
        .lg_fifo_depth_p(6)
    ) fpga_rx_link (
        .core_clk_i        (core_clk),
        .core_link_reset_i (fpga_core_reset),
        .io_link_reset_i   (fpga_rx_io_link_reset_sync),
        .core_data_o       (fpga_rx_data),
        .core_valid_o      (fpga_rx_valid),
        .core_yumi_i       (fpga_rx_yumi),
        .io_clk_i          (asic_to_fpga_clk),
        .io_data_i         (asic_to_fpga_data),
        .io_valid_i        (asic_to_fpga_valid),
        .core_token_r_o    (fpga_to_asic_token)
    );

    parity_checker #(.WIDTH_p(16)) check_low (
        .bits_i(fpga_rx_data[15:0]),
        .parity_i(fpga_rx_data[16]),
        .is_parity_o(rx_ok_low)
    );

    parity_checker #(.WIDTH_p(16)) check_high (
        .bits_i(fpga_rx_data[32:17]),
        .parity_i(fpga_rx_data[33]),
        .is_parity_o(rx_ok_high)
    );

    // Reassemble final 32-bit flit for the core
    assign rx_data_o = {rx_data_combined_lo[32:17], rx_data_combined_lo[15:0]};

    // Error logic: High if valid data has bad parity in either half
    assign rx_parity_error_o = rx_valid_o && (!rx_ok_low || !rx_ok_high);
    */

    // wire io_master_clk = core_clk;
    logic core_link_reset_int;
    logic io_link_reset_int;
    logic async_token_reset_int;

    bsg_link_wrapper #(
        .FLIT_WIDTH    (32),
        .CHANNEL_WIDTH (17)
    ) u_bsg_link_wrapper (
        .core_clk_i                (core_clk),
        .reset_i                   (core_link_reset_int), // fpga_core_reset
        .io_master_clk_i           (io_master_clk),
        .upstream_io_link_reset_i  (io_link_reset_int), // fpga_tx_io_link_reset
        .async_token_reset_i       (async_token_reset_int), // fpga_tx_async_token_reset
        .token_clk_i               (asic_to_fpga_token), // asic_to_fpga_token
        .downstream_io_link_reset_i(io_link_reset_int), // fpga_rx_io_link_reset_sync
        .downstream_io_clk_i       (asic_to_fpga_clk), // asic_to_fpga_clk
        .downstream_io_data_i      (asic_to_fpga_data),
        .downstream_io_valid_i     (asic_to_fpga_valid),
        .upstream_io_clk_r_o       (fpga_to_asic_clk),
        .upstream_io_data_r_o      (fpga_to_asic_data),
        .upstream_io_valid_r_o     (fpga_to_asic_valid),
        .downstream_core_token_r_o (fpga_to_asic_token),
        .rx_data_o                 (link_rx_data),
        .rx_valid_o                (link_rx_valid),
        .rx_yumi_i                 (fpga_rx_yumi),
        .rx_parity_error_o         (link_rx_parity_error),
        .tx_data_i                 (fpga_tx_data),
        .tx_valid_i                (fpga_tx_valid),
        .tx_ready_o                (link_tx_ready)
    );

    // ----- Internal reset sequencer for bsg_link init protocol -----
    // bsg_async_credit_counter requires:
    //   1. Assert r_reset (= io_link_reset, on io_clk domain).
    //   2. While r_reset asserted, pulse w_reset (= async_token_reset)
    //      0 -> 1 -> 0 at least once.
    //   3. Wait >=4 r_clock posedges before deasserting r_reset.
    //   4. Deassert r_reset.
    //
    // Tying every link reset to hard_reset would violate that ordering, so
    // the chip generates the staged reset internally from a single counter
    // that starts running once hard_reset deasserts.
    logic [5:0] reset_cnt = 6'd0;
    always @(posedge core_clk) begin
        if (hard_reset_sync)              reset_cnt <= 6'd0;
        else if (reset_cnt < 6'd63)  reset_cnt <= reset_cnt + 6'd1;
    end

    // async_token_reset: 0 normally, pulsed 1 during counts 2..4 after
    // hard_reset deasserts. Held 0 during hard_reset (matches bsg ref tb).
    logic async_token_reset_int;
    assign async_token_reset_int = ~hard_reset_sync
                                 && (reset_cnt >= 6'd2)
                                 && (reset_cnt <  6'd5);

    // io_link_resets: held high while hard_reset is asserted, then for
    // ~16 more core_clk cycles after the async_token_reset pulse.
    logic io_link_reset_int;
    assign io_link_reset_int  = hard_reset_sync || (reset_cnt < 6'd16);

    // core link reset: released last (~32 cycles after hard_reset).
    logic core_link_reset_int;
    assign core_link_reset_int = hard_reset_sync || (reset_cnt < 6'd32);

    always_comb begin
        pad_oe[44] = 1'b1; pad_oe[45] = 1'b1;
        pad_oe[8]  = 1'b1; pad_oe[9]  = 1'b1;
        pad_oe[12] = 1'b1;
        // pad_oe[13] = 1'b1; pad_oe[24] = 1'b1; pad_oe[26] = 1'b1;
        pad_oe[11] = 1'b1; pad_oe[46] = 1'b1;
        for (int dn = 0; dn < 8; dn++) pad_oe[dn] = 1'b1;
        pad_oe[37] = 1'b1; pad_oe[36] = 1'b1;
        pad_oe[39] = 1'b1; pad_oe[38] = 1'b1;
        pad_oe[41] = 1'b1; pad_oe[40] = 1'b1;
        pad_oe[43] = 1'b1; pad_oe[42] = 1'b1;
        pad_oe[27] = 1'b1;
    end

    // assign fpga_rx_yumi = link_rx_valid;

    // Track FPGA-side RX from chip
    logic [DATA_WIDTH-1:0] link_last_rx_data;
    integer                fpga_rx_count;
    always_ff @(posedge core_clk) begin
        if (hard_reset) begin
            fpga_rx_count     <= 0;
            link_last_rx_data <= '0;
        end else if (link_rx_valid && fpga_rx_yumi) begin
            fpga_rx_count     <= fpga_rx_count + 1;
            link_last_rx_data <= link_rx_data;
        end
    end

    // // ----- Clock generation -----
    // initial begin
    //     core_clk = 1'b0;
    //     forever #10000 core_clk = ~core_clk;      // 50 MHz
    // end

    // initial begin
    //     dn_io_clk = 1'b0;
    //     forever #10000 dn_io_clk = ~dn_io_clk;    // 50 MHz → bsg_link_oddr_phy ÷2 → 25 MHz forwarded clock at PAD[8]
    // end

    //logic tr_v_lo;
    //logic [DATA_WIDTH-1:0] tr_data_lo;
    logic tr_yumi_li;
    logic [DATA_WIDTH+4-1:0] rom_data_send, rom_data_recv;
    logic [31:0] rom_addr_send, rom_addr_recv;
    logic done_send, done_recv;

    // --- Send Trace Replay (Feeds in_flit) ---
    bsg_fsb_node_trace_replay #(
        .ring_width_p(DATA_WIDTH)
       ,.rom_addr_width_p(32)
    ) tracer_send (
         .clk_i  (~core_clk) // Run replay on opposite edge for stability
        ,.reset_i(core_link_reset_int)
        ,.en_i   (1'b1)
        
        ,.v_i    (1'b0)
        ,.data_i ('0)
        ,.ready_o()

        ,.v_o    (fpga_tx_valid)
        ,.data_o (fpga_tx_data)
        ,.yumi_i (tr_yumi_li)

        ,.rom_addr_o(rom_addr_send)
        ,.rom_data_i(rom_data_send)
        ,.done_o    (done_send)
        ,.error_o   ()
    );

    // Mapping Trace Replay to Top Level Input
    // assign fpga_tx_data   = tr_data_lo;
    // assign fpga_tx_valid  = tr_v_lo;
    // assign in_flit_par_ok = 1'b1; // Assuming parity is always good for functional test
    assign tr_yumi_li     = link_tx_ready & fpga_to_asic_valid;

    logic tr_ready_lo;
    logic tr_v_li;
    logic[31:0] link_out_data_o_r;

    always_ff @(negedge core_clk) begin 
        fpga_rx_yumi <= tr_ready_lo && link_rx_valid;
        tr_v_li <= link_rx_valid;
        link_out_data_o_r <= link_rx_data;
    end

    // --- Receive Trace Replay (Validates link_out) ---
    bsg_fsb_node_trace_replay #(
        .ring_width_p(DATA_WIDTH)
       ,.rom_addr_width_p(32)
    ) tracer_recv (
         .clk_i  (~core_clk)
        ,.reset_i(core_link_reset_int)
        ,.en_i   (1'b1)

        ,.v_i    (tr_v_li)
        ,.data_i (link_out_data_o_r)
        ,.ready_o(tr_ready_lo) // This ready effectively acts as 'yumi' for the DUT

        ,.v_o    ()
        ,.data_o ()
        ,.yumi_i (1'b0)

        ,.rom_addr_o(rom_addr_recv)
        ,.rom_data_i(rom_data_recv)
        ,.done_o    (done_recv)
        ,.error_o   ()
    );

    benchmark4_send_trace_rom #(.width_p(DATA_WIDTH+4), .addr_width_p(32)) 
        ROM_send (.addr_i(rom_addr_send), .data_o(rom_data_send));
    benchmark4_recv_trace_rom #(.width_p(DATA_WIDTH+4), .addr_width_p(32))
        ROM_recv (.addr_i(rom_addr_recv), .data_o(rom_data_recv));

    /*
    // ----- Stimulus tasks -----
    task automatic send_link_word(input logic [FLIT_WIDTH-1:0] data);
        begin
            fpga_tx_data  <= data;
            fpga_tx_valid <= 1'b1;
            do begin
                @(posedge core_clk);
            end while (!fpga_tx_ready);
            fpga_tx_valid <= 1'b0;
            @(posedge core_clk);
        end
    endtask

    // Bit-banged SPI write of 298 bits (rw_bit=0 + 297 data bits MSB-first).
    // The first data bit (MSB after rw_bit) becomes reg_out[297] = spi_reg_enable.
    task automatic spi_write(input logic [297:0] data);
        integer i;
        begin
            @(negedge SCLK);
            SS_n = 1'b0;
            MOSI = 1'b0;          // rw_bit = 0 (write)
            @(negedge SCLK);
            for (i = 297; i >= 0; i = i - 1) begin
                MOSI = data[i];
                @(negedge SCLK);
            end
            @(negedge SCLK);
            @(negedge SCLK);
            SS_n = 1'b1;
        end
    endtask

    // SPI clock generation (4 MHz)
    initial begin
        SCLK = 1'b0;
        forever #125000 SCLK = ~SCLK;
    end

    // ----- Main test sequence -----
    initial begin
        // VCD for legacy/open-source viewers; FSDB for Verdi
        // (`make view-sim-rtl`, `make view-sim-syn`, `make view-sim-par`).
        // FSDB lives in the run dir alongside simv with the canonical
        // name Hammer's vcs-mk view-sim-* targets look for.
        $dumpfile("chip_top_tb.vcd");
        $dumpvars(0, chip_top_tb);
        $fsdbDumpfile("waveform.fsdb");
        $fsdbDumpvars(0, chip_top_tb);
        $fsdbDumpMDA();   // pack arrays so DDR data buses stay readable

        hard_reset                = 1'b1;
        fpga_core_reset           = 1'b1;
        fpga_tx_io_link_reset     = 1'b1;
        fpga_tx_async_token_reset = 1'b0;
        fpga_rx_io_link_reset     = 1'b1;
        fpga_tx_valid             = 1'b0;
        fpga_tx_data              = '0;
        SS_n                      = 1'b1;
        MOSI                      = 1'b0;
        pad_oe                    = '0;

        // Let chip_top configure pad directions first.
        #1000;
        pad_oe[44] = 1'b1; pad_oe[45] = 1'b1;
        pad_oe[8]  = 1'b1; pad_oe[9]  = 1'b1;
        pad_oe[12] = 1'b1;
        pad_oe[13] = 1'b1; pad_oe[24] = 1'b1; pad_oe[26] = 1'b1;
        pad_oe[11] = 1'b1; pad_oe[46] = 1'b1;
        for (int dn = 0; dn < 8; dn++) pad_oe[dn] = 1'b1;
        pad_oe[37] = 1'b1; pad_oe[36] = 1'b1;
        pad_oe[39] = 1'b1; pad_oe[38] = 1'b1;
        pad_oe[41] = 1'b1; pad_oe[40] = 1'b1;
        pad_oe[43] = 1'b1; pad_oe[42] = 1'b1;

        // Reset bring-up order for our chip:
        //  1) Pulse FPGA TX async_token_reset (chip RX side will see tokens
        //     once data starts flowing).
        //  2) Release FPGA TX I/O link reset (FPGA TX starts driving the
        //     chip's RX-side data clock).
        //  3) Release chip's hard_reset. The chip's internal reset
        //     sequencer takes ~32 core_clks to bring its bsg_link out of
        //     reset (async_token pulse, io_link, then core).
        //  4) After the chip is running, release FPGA RX I/O link reset
        //     so the FPGA RX side sees a valid up_clk from the chip.
        //  5) Release FPGA core reset.
        repeat (8) @(posedge core_clk);
        fpga_tx_async_token_reset = 1'b1;
        repeat (2) @(posedge core_clk);
        fpga_tx_async_token_reset = 1'b0;

        repeat (8) @(posedge dn_io_clk);
        fpga_tx_io_link_reset = 1'b0;

        // Release chip's hard_reset; wait for its internal sequencer to
        // finish (>=32 core_clks).
        repeat (8) @(posedge core_clk);
        hard_reset = 1'b0;
        repeat (64) @(posedge core_clk);

        // Now the chip is driving up_clk; safe to bring up FPGA RX.
        fpga_rx_io_link_reset = 1'b0;
        repeat (8) @(posedge core_clk);
        fpga_core_reset = 1'b0;

        // Let chip exit reset and start emitting status words
        repeat (200) @(posedge core_clk);
        $display("post-reset: rx_count=%0d, last_status=%h",
                 fpga_rx_count, fpga_last_rx_data);

        // Test 1: bsg_link config write (10 words)
        $display("Test 1: send 10 bsg_link config words to chip RX");
        for (int w = 0; w < 10; w++) begin
            send_link_word(32'hC0DE_0000 | w);
        end
        repeat (200) @(posedge core_clk);

        if (fpga_last_rx_data[3] !== 1'b1) begin
            $display("WARN: expected link_cfg_active=1 in chip status, got status=%h",
                     fpga_last_rx_data);
        end else begin
            $display("Test 1 PASS: link_cfg_active=1, rx_word_count=%0d, status=%h",
                     fpga_last_rx_data[15:8], fpga_last_rx_data);
        end

        // Test 2: SPI write with spi_reg_enable=1
        $display("Test 2: SPI write with spi_reg_enable=1");
        spi_write({
            1'b1,                                                              // spi_reg_enable
            1'b1,                                                              // transmit_enable
            232'hAABBCCDDEEFF00112233445566778899AABBCCDDEEFF00112233445566,   // packet_in
            8'd2, 8'd64, 16'd20000, 8'd8, 8'd16, 8'd10, 8'd20
        });
        repeat (1000) @(posedge core_clk);

        if (fpga_last_rx_data[2] !== 1'b1) begin
            $display("WARN: expected spi_reg_enable=1 in chip status, got status=%h",
                     fpga_last_rx_data);
        end else begin
            $display("Test 2 PASS: spi_reg_enable=1, status=%h", fpga_last_rx_data);
        end

        $display("BSG_LINK_PAD_LOOPBACK_PASS rx_count=%0d last_status=%h",
                 fpga_rx_count, fpga_last_rx_data);
        $finish;
    end

    // Watchdog
    initial begin
        #50_000_000_000;  // 50 us
        $display("ERROR: testbench watchdog expired");
        $finish;
    end
    */

endmodule

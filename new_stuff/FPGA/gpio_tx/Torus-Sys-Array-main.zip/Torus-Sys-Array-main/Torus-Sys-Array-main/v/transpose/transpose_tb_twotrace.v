`timescale 1ns / 1ps

module transpose_tb_twotrace;

    /* Dump Test Waveform To VPD File */
  initial begin
    $fsdbDumpfile("waveform.fsdb");
    $fsdbDumpvars("+all");
  end

  /* Non-synth clock generator */
  logic clk;
  bsg_nonsynth_clock_gen #(12000) clk_gen_1 (clk);

  /* Non-synth reset generator */
  logic reset;
  bsg_nonsynth_reset_gen #(.num_clocks_p(1),.reset_cycles_lo_p(5),. reset_cycles_hi_p(5))
    reset_gen
      (.clk_i        ( clk )
      ,.async_reset_o( reset )
      );

  logic dut_v_lo, dut_v_r;
  logic [64:0] dut_data_lo, dut_data_r;
  logic dut_ready_lo, dut_ready_r;

  logic tr_v_lo;
  logic [64:0] tr_data_lo;
  logic tr_ready_lo, tr_ready_r;

  logic [31:0] rom_addr_li;
  logic [68:0] rom_data_lo_send, rom_data_lo_recv;

  logic tr_yumi_li, dut_yumi_li;
  logic valid_i_r;

  bsg_fsb_node_trace_replay #(.ring_width_p(65)
                             ,.rom_addr_width_p(32) )
    trace_replay_recv
      ( .clk_i ( ~clk ) // Trace Replay should run on negative clock edge!
      , .reset_i( reset )
      , .en_i( 1'b1 )

      , .v_i    ( dut_v_r )
      , .data_i ( dut_data_r )
      , .ready_o( tr_ready_lo )

      , .v_o   (  )
      , .data_o(  )
      , .yumi_i( tr_yumi_li )

      , .rom_addr_o(  )
      , .rom_data_i( rom_data_lo_recv )

      , .done_o()
      , .error_o()
      );

  bsg_fsb_node_trace_replay #(.ring_width_p(65)
                             ,.rom_addr_width_p(32) )
    trace_replay_send
      ( .clk_i ( ~clk ) // Trace Replay should run on negative clock edge!
      , .reset_i( reset )
      , .en_i( 1'b1 )

      , .v_i    ( dut_v_r )
      , .data_i (  )
      , .ready_o(  )

      , .v_o   ( tr_v_lo )
      , .data_o( tr_data_lo )
      , .yumi_i( tr_yumi_li )

      , .rom_addr_o( rom_addr_li )
      , .rom_data_i( rom_data_lo_send )

      , .done_o()
      , .error_o()
      );

  always_ff @(negedge clk) begin
    dut_ready_r <= dut_ready_lo;
    //tr_yumi_li  <= dut_ready_r & tr_v_lo;
    tr_yumi_li <= 1'b1;
    dut_v_r     <= dut_v_lo;
    dut_data_r  <= dut_data_lo;

    valid_i_r <= tr_v_lo;
  end

  transpose_recv_trace_rom #(.width_p(69),.addr_width_p(32))
    ROM_BPS_recv
      (.addr_i( rom_addr_li )
      ,.data_o( rom_data_lo_recv )
      );
  transpose_send_trace_rom #(.width_p(69),.addr_width_p(32))
    ROM_BPS_send
      (.addr_i( rom_addr_li )
      ,.data_o( rom_data_lo_send )
      );

  transpose #(.WIDTH_P(8), .DIM_p(8))
    DUT
    (.clk_i    ( clk )
    ,.rst_n_i  ( ~reset )

    ,.in_data ( {tr_data_lo[63:56], tr_data_lo[55:48], tr_data_lo[47:40], tr_data_lo[39:32],
                 tr_data_lo[31:24], tr_data_lo[23:16], tr_data_lo[15:8],  tr_data_lo[7:0]} )
    //,.\in_data[3] ( {tr_data_lo[31:24]} )
    //,.\in_data[2] ( {tr_data_lo[23:16]} )
    //,.\in_data[1] ( {tr_data_lo[15:8]} )
    //,.\in_data[0] ( {tr_data_lo[7:0]} )

    ,.valid_i ( tr_v_lo )
    ,.ready_i ( dut_yumi_li )

    ,.valid_o ( dut_v_lo )
    ,.ready_o ( dut_ready_lo )

    ,.transpose(tr_data_lo[64])

    ,.out_data ( {dut_data_lo[63:56], dut_data_lo[55:48], dut_data_lo[47:40], dut_data_lo[39:32],
                  dut_data_lo[31:24], dut_data_lo[23:16], dut_data_lo[15:8], dut_data_lo[7:0]} )
    //,.\out_data[3] ( {dut_data_lo[31:24]} )
    //,.\out_data[2] ( {dut_data_lo[23:16]} )
    //,.\out_data[1] ( {dut_data_lo[15:8]} )
    //,.\out_data[0] ( {dut_data_lo[7:0]} )
    );
  
  assign dut_data_lo[64] = 1'b0;

  // no handshake logic. all ready/valid signal is 1.
  //assign dut_ready_lo = '1;
  //assign dut_v_lo = '1;

  always_ff @(negedge clk) begin
    //dut_yumi_li <= tr_ready_lo & dut_v_lo;
  end
  assign dut_yumi_li = tr_ready_lo & dut_v_lo;


endmodule